For Princeton University's class COS-418, Fall 2016: Distributed Systems at [https://www.cs.princeton.edu/courses/archive/fall16/cos418/index.html](https://www.cs.princeton.edu/courses/archive/fall16/cos418/index.html)

