package GlobalSnapshot;

public class Event {}
