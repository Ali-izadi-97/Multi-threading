package GlobalSnapshot;

public class Marker extends Event {}
